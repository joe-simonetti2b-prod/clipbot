"""
Configuration centralisée du bot.

Toutes les valeurs sensibles (clés API, secrets) viennent de variables
d'environnement (fichier /opt/clipbot/.env sur Oracle, onglet « Environment » sur Render) — jamais du code.
Les réglages modifiables depuis Telegram (/auto, /pause, chaînes suivies…)
sont stockés en base et priment sur ces valeurs par défaut.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path


def _env(name: str, default: str = "", cast=str):
    """Champ lu dans l'environnement au moment de l'instanciation."""
    return field(default_factory=lambda: cast(os.getenv(name, default)))


def _env_list(name: str, default: str = "") -> list[str]:
    raw = os.getenv(name, default)
    return [x.strip().lower() for x in raw.split(",") if x.strip()]


def _bool(v: str) -> bool:
    return v.strip().lower() in {"1", "true", "yes", "oui", "on"}


@dataclass
class DiscoveryConfig:
    twitch_client_id: str = _env("TWITCH_CLIENT_ID")
    twitch_client_secret: str = _env("TWITCH_CLIENT_SECRET")
    youtube_api_key: str = _env("YOUTUBE_API_KEY")
    kick_client_id: str = _env("KICK_CLIENT_ID")
    kick_client_secret: str = _env("KICK_CLIENT_SECRET")

    languages: list[str] = field(default_factory=lambda: _env_list("LANGUAGES", "fr"))
    # Catégories Twitch (game_id) — 518203 = Sports, 509658 = Just Chatting
    twitch_game_ids: list[str] = field(default_factory=lambda: _env_list("TWITCH_GAME_IDS"))
    # Catégories YouTube : 17 = Sports, 20 = Gaming, 24 = Entertainment
    youtube_category_ids: list[str] = field(
        default_factory=lambda: _env_list("YOUTUBE_CATEGORY_IDS", "17,20,24")
    )
    min_viewers: int = _env("MIN_VIEWERS", "1500", int)
    max_concurrent_streams: int = _env("MAX_CONCURRENT_STREAMS", "3", int)
    poll_interval_s: int = _env("DISCOVERY_INTERVAL_S", "300", int)
    # Chaînes autorisées. Complétable depuis Telegram (/add, /remove).
    allowed_channels: list[str] = field(default_factory=lambda: _env_list("ALLOWED_CHANNELS"))


@dataclass
class HypeConfig:
    window_s: float = 10.0          # fenêtre glissante de mesure
    baseline_alpha: float = 0.02    # vitesse d'adaptation de la moyenne mobile (EWMA)
    z_threshold: float = 3.0        # écart au bruit de fond pour déclencher
    min_msgs_per_s: float = 1.5     # plancher absolu (évite les faux positifs sur petits chats)
    warmup_s: float = 60.0          # temps d'apprentissage avant tout déclenchement
    cooldown_s: float = 45.0        # délai minimal entre deux clips d'un même live
    chat_delay_s: float = 8.0       # le chat réagit en retard sur l'image
    # LONG_CLIPS=true -> clips de ~65 s (éligibilité aux fonds créateurs > 1 min)
    pre_roll_s: float = field(default_factory=lambda: 45.0 if _bool(os.getenv("LONG_CLIPS", "")) else 25.0)
    post_roll_s: float = field(default_factory=lambda: 20.0 if _bool(os.getenv("LONG_CLIPS", "")) else 15.0)


@dataclass
class CaptureConfig:
    work_dir: Path = _env("CLIPBOT_WORKDIR", "./data", Path)
    segment_s: int = 6              # durée d'un segment du tampon circulaire
    buffer_s: int = 300             # profondeur du tampon (5 min de live gardées)
    stream_format: str = _env("STREAM_FORMAT", "best[height<=1080]/best")
    reencode: bool = False          # la découpe brute copie ; le montage 9:16 ré-encode ensuite


@dataclass
class ProcessingConfig:
    # Transcription : Groq (gratuit, rapide, 0 RAM locale) si GROQ_API_KEY, sinon Whisper local
    groq_api_key: str = _env("GROQ_API_KEY")
    whisper_model: str = _env("WHISPER_MODEL", "small")      # tiny/base/small : qualité vs CPU
    whisper_threads: int = _env("WHISPER_THREADS", "2", int)
    whisper_keep_loaded: bool = _env("WHISPER_KEEP_LOADED", "false", _bool)
    # Sortie vidéo : 1920 (1080×1920) ou 1280 (720×1280, pour petites machines)
    output_height: int = _env("OUTPUT_HEIGHT", "1920", int)
    x264_preset: str = _env("X264_PRESET", "veryfast")
    font: str = _env("SUBTITLE_FONT", "DejaVu Sans")
    anthropic_api_key: str = _env("ANTHROPIC_API_KEY")        # optionnel : textes + tri IA
    anthropic_model: str = _env("ANTHROPIC_MODEL", "claude-haiku-4-5-20251001")
    min_ai_score: int = _env("MIN_AI_SCORE", "5", int)       # clips notés en dessous = jetés
    cta_text: str = _env("CTA_TEXT")                           # ex : "Lien en bio 🔗"
    ad_disclosure: bool = _env("AD_DISCLOSURE", "false", _bool)  # ajoute « Publicité »
    retention_days: int = _env("RETENTION_DAYS", "3", int)


@dataclass
class PublishConfig:
    telegram_token: str = _env("TELEGRAM_BOT_TOKEN")
    telegram_pair_code: str = _env("TELEGRAM_PAIR_CODE")
    # Facultatif : évite de refaire /start sur un hébergeur sans disque persistant
    telegram_owner_id: str = _env("TELEGRAM_OWNER_ID")
    tiktok_client_key: str = _env("TIKTOK_CLIENT_KEY")
    tiktok_client_secret: str = _env("TIKTOK_CLIENT_SECRET")
    # inbox  = brouillon dans l'app TikTok (fonctionne avant l'audit, 5/jour max)
    # direct = publication publique directe (nécessite l'audit TikTok)
    tiktok_mode: str = _env("TIKTOK_MODE", "inbox")
    auto_publish: bool = _env("AUTO_PUBLISH", "false", _bool)


@dataclass
class ServerConfig:
    port: int = _env("PORT", "8080", int)
    # Render fournit RENDER_EXTERNAL_URL automatiquement ; ailleurs, PUBLIC_URL
    public_url: str = field(default_factory=lambda: (
        os.getenv("PUBLIC_URL") or os.getenv("RENDER_EXTERNAL_URL") or ""
    ).rstrip("/"))
    # Render gratuit s'endort après 15 min sans visite : le bot se réveille lui-même
    keepalive: bool = field(default_factory=lambda: _bool(
        os.getenv("KEEPALIVE", "true" if os.getenv("RENDER_EXTERNAL_URL") else "false")))
    contact_email: str = _env("CONTACT_EMAIL")


@dataclass
class Settings:
    discovery: DiscoveryConfig = field(default_factory=DiscoveryConfig)
    hype: HypeConfig = field(default_factory=HypeConfig)
    capture: CaptureConfig = field(default_factory=CaptureConfig)
    processing: ProcessingConfig = field(default_factory=ProcessingConfig)
    publish: PublishConfig = field(default_factory=PublishConfig)
    server: ServerConfig = field(default_factory=ServerConfig)
