"""
Textes de publication : accroche (hook), légende, hashtags, note de viralité.

Avec ANTHROPIC_API_KEY : Claude lit la transcription et le contexte du live,
écrit le texte ET note le clip de 1 à 10 — les clips sous MIN_AI_SCORE sont
jetés automatiquement (moins de tri pour toi).
Sans clé : textes générés par gabarits, aucun tri automatique.

Crédit du streamer et mention « Publicité » sont ajoutés par le code, jamais
laissés au bon vouloir du modèle.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass

import aiohttp

log = logging.getLogger(__name__)

PLATFORM_LABEL = {"twitch": "Twitch", "kick": "Kick", "youtube": "YouTube"}
REASON_HOOK = {
    "rire": "Personne ne s'attendait à ça 😂",
    "action": "Le moment où tout le chat a explosé 🔥",
    "demande_clip": "Le chat a crié « CLIP ! » 🎬",
    "burst": "Regarde jusqu'à la fin 👀",
}

PROMPT = """Tu es éditeur de clips courts viraux (TikTok/Shorts) pour du streaming, du sport et de l'entertainment.

Contexte du live :
- Chaîne : {channel} ({platform})
- Titre du live : {title}
- Catégorie : {category}
- Signal du chat au moment du pic : {reason} (mots dominants : {tokens})

Transcription du clip ({duration:.0f} s) :
\"\"\"{transcript}\"\"\"

Réponds UNIQUEMENT avec un objet JSON, en {lang} :
{{
  "score": entier 1-10 (le clip est-il compréhensible et captivant SANS contexte ? 10 = viral évident, 1 = rien ne se passe),
  "hook": "accroche de 4 à 9 mots affichée en haut de la vidéo, qui donne envie de rester sans spoiler la chute",
  "caption": "légende de 1 à 2 phrases, naturelle, qui pousse au commentaire",
  "hashtags": ["5 à 7 hashtags pertinents, sans #, mélange niche + large"]
}}"""


@dataclass
class Copy:
    hook: str
    caption: str
    score: int | None


def _finalize(body: str, hashtags: list[str], channel: str, platform: str,
              cta: str, ad: bool) -> str:
    tags = " ".join("#" + re.sub(r"[^\w]", "", t.lstrip("#")) for t in hashtags if t.strip())
    parts = []
    if ad:
        parts.append("Publicité")
    parts.append(body.strip())
    parts.append(f"🎥 {channel} en live sur {PLATFORM_LABEL.get(platform, platform)}")
    if cta:
        parts.append(cta)
    parts.append(tags)
    return "\n\n".join(p for p in parts if p)[:2000]


def fallback_copy(clip: dict, cta: str, ad: bool) -> Copy:
    title = (clip.get("stream_title") or "").strip()
    hook = REASON_HOOK.get(clip.get("reason"), REASON_HOOK["burst"])
    cat = re.sub(r"[^\w]", "", (clip.get("category") or "").lower())
    tags = [t for t in (cat, clip.get("channel", ""), "clip", "stream", "pourtoi", "fyp") if t]
    body = title[:150] if title else hook
    return Copy(hook, _finalize(body, tags, clip["channel"], clip["platform"], cta, ad), None)


async def write_copy(session: aiohttp.ClientSession, api_key: str, model: str, clip: dict,
                     transcript: str, language: str, cta: str, ad: bool) -> Copy:
    if not api_key:
        return fallback_copy(clip, cta, ad)
    prompt = PROMPT.format(
        channel=clip["channel"], platform=PLATFORM_LABEL.get(clip["platform"], clip["platform"]),
        title=clip.get("stream_title") or "?", category=clip.get("category") or "?",
        reason=clip.get("reason"), tokens=clip.get("tokens") or "?",
        duration=clip.get("trim_duration") or 0,
        transcript=(transcript or "(aucune parole détectée)")[:4000],
        lang="anglais" if language == "en" else "français",
    )
    try:
        async with session.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": api_key, "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={"model": model, "max_tokens": 600,
                  "messages": [{"role": "user", "content": prompt}]},
            timeout=aiohttp.ClientTimeout(total=60),
        ) as r:
            r.raise_for_status()
            data = await r.json()
        text = "".join(b.get("text", "") for b in data.get("content", []))
        obj = json.loads(re.search(r"\{.*\}", text, re.S).group(0))
        return Copy(
            hook=str(obj.get("hook", "")).strip()[:90],
            caption=_finalize(str(obj.get("caption", "")), list(obj.get("hashtags", []))[:8],
                              clip["channel"], clip["platform"], cta, ad),
            score=int(obj.get("score", 5)),
        )
    except Exception as e:
        log.warning("Rédaction IA indisponible (%s) -> gabarit", e)
        return fallback_copy(clip, cta, ad)
