"""
Choix automatique de la mise en page verticale 9:16.

On échantillonne ~1 image/s et on cherche des visages (cascade Haar
d'OpenCV : rapide sur CPU, aucun modèle à télécharger). Trois cas :

  face  : un visage occupe une bonne partie de l'image (IRL, Just Chatting,
          interview, réaction) -> recadrage 9:16 centré sur le visage.
  split : petit visage fixe dans un coin (facecam de gameplay)
          -> facecam en haut, jeu en bas : le format qui performe le mieux.
  blur  : pas de visage exploitable (match, gameplay sans cam)
          -> image entière au centre sur fond flouté, rien n'est coupé.
"""
from __future__ import annotations

import asyncio
import logging
import statistics
from dataclasses import dataclass
from pathlib import Path

log = logging.getLogger(__name__)


@dataclass
class Layout:
    kind: str                      # "face" | "split" | "blur"
    cx: float = 0.5                # centre horizontal du visage (0..1) — mode face
    cam: tuple[float, float, float, float] | None = None  # x, y, w, h (0..1) — mode split


def _analyze_sync(src: Path, offset: float, duration: float) -> Layout:
    import cv2

    cv2.setNumThreads(1)  # machine gratuite : pas de pool de fils gourmand en RAM
    cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    cap = cv2.VideoCapture(str(src))
    faces: list[tuple[float, float, float, float]] = []
    samples = 0
    t = offset
    while t < offset + duration:
        cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000)
        ok, frame = cap.read()
        t += 1.0
        if not ok:
            continue
        samples += 1
        h, w = frame.shape[:2]
        scale = 640 / w
        small = cv2.resize(frame, (640, int(h * scale)))
        gray = cv2.equalizeHist(cv2.cvtColor(small, cv2.COLOR_BGR2GRAY))
        found = cascade.detectMultiScale(gray, scaleFactor=1.15, minNeighbors=6, minSize=(24, 24))
        if len(found):
            x, y, fw, fh = max(found, key=lambda r: r[2] * r[3])
            sw, sh = small.shape[1], small.shape[0]
            faces.append((x / sw, y / sh, fw / sw, fh / sh))
    cap.release()

    if samples == 0 or len(faces) / samples < 0.5:
        return Layout("blur")

    cxs = [f[0] + f[2] / 2 for f in faces]
    cys = [f[1] + f[3] / 2 for f in faces]
    fws = [f[2] for f in faces]
    cx, cy, fw = statistics.median(cxs), statistics.median(cys), statistics.median(fws)
    stable = len(faces) > 2 and statistics.pstdev(cxs) < 0.04 and statistics.pstdev(cys) < 0.04
    near_edge = min(cx, 1 - cx) < 0.3 or min(cy, 1 - cy) < 0.3

    if fw >= 0.09:
        return Layout("face", cx=cx)
    if stable and near_edge:
        # La facecam fait ~3,5× la largeur du visage, au format 16:9.
        cw = min(1.0, fw * 3.5)
        ch = cw  # en coordonnées normalisées, une boîte 16:9 dans une image 16:9 a w == h
        x = min(max(cx - cw / 2, 0.0), 1 - cw)
        y = min(max(cy - ch / 2, 0.0), 1 - ch)
        return Layout("split", cam=(x, y, cw, ch))
    return Layout("blur")


async def analyze(src: Path, offset: float, duration: float) -> Layout:
    try:
        layout = await asyncio.to_thread(_analyze_sync, src, offset, duration)
    except Exception as e:
        log.warning("Analyse de cadrage impossible (%s) -> fond flouté", e)
        layout = Layout("blur")
    log.info("Mise en page choisie : %s", layout.kind)
    return layout
