"""
Accès unifié aux modèles de langage pour la rédaction, la note et la traduction.

Ordre de préférence :
  1. Claude (ANTHROPIC_API_KEY)  — meilleure qualité, payant à l'usage
  2. Groq   (GROQ_API_KEY)       — gratuit, déjà utilisé pour la transcription
  3. aucun  -> gabarits sans IA

Chaque appel demande un objet JSON et renvoie None en cas d'échec : l'appelant
retombe toujours sur un comportement sans IA, un clip n'est jamais bloqué.
"""
from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass

import aiohttp

log = logging.getLogger(__name__)

GROQ_CHAT = "https://api.groq.com/openai/v1/chat/completions"
ANTHROPIC = "https://api.anthropic.com/v1/messages"


@dataclass
class LLM:
    provider: str      # "anthropic" | "groq" | ""
    key: str
    model: str

    @classmethod
    def from_settings(cls, p) -> "LLM":
        if p.anthropic_api_key:
            return cls("anthropic", p.anthropic_api_key, p.anthropic_model)
        if p.groq_api_key:
            return cls("groq", p.groq_api_key, p.groq_llm_model)
        return cls("", "", "")

    @property
    def enabled(self) -> bool:
        return bool(self.provider)


def _extract_json(text: str) -> dict | list | None:
    m = re.search(r"(\{.*\}|\[.*\])", text, re.S)
    return json.loads(m.group(1)) if m else None


async def ask_json(session: aiohttp.ClientSession, llm: LLM, prompt: str,
                   max_tokens: int = 800) -> dict | None:
    if not llm.enabled:
        return None
    try:
        if llm.provider == "anthropic":
            async with session.post(
                ANTHROPIC,
                headers={"x-api-key": llm.key, "anthropic-version": "2023-06-01",
                         "content-type": "application/json"},
                json={"model": llm.model, "max_tokens": max_tokens,
                      "messages": [{"role": "user", "content": prompt}]},
                timeout=aiohttp.ClientTimeout(total=60),
            ) as r:
                r.raise_for_status()
                data = await r.json()
            text = "".join(b.get("text", "") for b in data.get("content", []))
        else:
            async with session.post(
                GROQ_CHAT,
                headers={"Authorization": f"Bearer {llm.key}"},
                json={"model": llm.model, "max_tokens": max_tokens, "temperature": 0.7,
                      "response_format": {"type": "json_object"},
                      "messages": [
                          {"role": "system", "content": "Tu réponds uniquement par un objet JSON valide."},
                          {"role": "user", "content": prompt}]},
                timeout=aiohttp.ClientTimeout(total=60),
            ) as r:
                if r.status != 200:
                    raise RuntimeError(f"HTTP {r.status} : {(await r.text())[:200]}")
                data = await r.json()
            text = data["choices"][0]["message"]["content"]
        obj = _extract_json(text)
        return obj if isinstance(obj, dict) else None
    except Exception as e:
        log.warning("IA (%s) indisponible : %s", llm.provider, e)
        return None
