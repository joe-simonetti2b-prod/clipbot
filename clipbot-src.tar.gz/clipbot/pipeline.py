"""
Pipeline de post-production et de publication.

  Processor  : extracted -> processing -> ready | discarded | failed
               transcription -> textes IA (+ note) -> cadrage 9:16 -> montage
               -> envoi Telegram (ou publication directe si /auto on)
  Publisher  : approved -> publishing -> published | failed
  Janitor    : supprime les fichiers des clips terminés après RETENTION_DAYS

Un seul montage à la fois (CPU limité, coût maîtrisé) ; la détection et la
capture continuent en parallèle, les clips attendent en file dans SQLite.
"""
from __future__ import annotations

import asyncio
import logging
import time
from pathlib import Path

import aiohttp

from .config import Settings
from .copywriter import write_copy
from .layout import analyze
from .render import render
from .storage import Store
from .subtitles import build_ass
from .telegram import TelegramBot
from .tiktok import TikTokClient, TikTokError
from .transcribe import transcribe

log = logging.getLogger(__name__)

EMOJI = {"rire": "😂", "action": "🔥", "demande_clip": "🎬", "burst": "⚡"}


class Pipeline:
    def __init__(self, settings: Settings, store: Store, session: aiohttp.ClientSession,
                 telegram: TelegramBot, tiktok: TikTokClient):
        self.s = settings
        self.store = store
        self.session = session
        self.tg = telegram
        self.tiktok = tiktok
        self.final_dir = settings.capture.work_dir / "final"
        self.final_dir.mkdir(parents=True, exist_ok=True)
        self._process_wake = asyncio.Event()
        self._publish_wake = asyncio.Event()
        telegram.on_approve = self.approve
        telegram.on_reject = self.reject

    # ------------------------------------------------------------- entrées
    def wake(self) -> None:
        self._process_wake.set()

    @property
    def auto(self) -> bool:
        return self.store.get("auto_publish", self.s.publish.auto_publish)

    async def approve(self, clip_id: int) -> str:
        if self.store.claim(clip_id, "ready", "approved"):
            self._publish_wake.set()
            if not (self.tiktok.configured and self.tiktok.connected):
                return "Validé ✅ (TikTok non connecté : publie-le depuis la vidéo)"
            return "Envoi vers TikTok… 🚀"
        return "Déjà traité"

    async def reject(self, clip_id: int) -> str:
        if self.store.claim(clip_id, "ready", "rejected"):
            return "Jeté 🗑️"
        return "Déjà traité"

    # ------------------------------------------------------- post-production
    async def run_processor(self) -> None:
        while True:
            row = self.store.next_clip("extracted")
            if row is None:
                self._process_wake.clear()
                try:
                    await asyncio.wait_for(self._process_wake.wait(), 30)
                except asyncio.TimeoutError:
                    pass
                continue
            if not self.store.claim(row["id"], "extracted", "processing"):
                continue
            try:
                await self._process(dict(row))
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.exception("Clip %s en échec", row["id"])
                self.store.update_clip(row["id"], status="failed", error=str(e)[:500])

    async def _process(self, clip: dict) -> None:
        cid = clip["id"]
        src = Path(clip["raw_path"])
        if not src.exists():
            raise FileNotFoundError(src)
        offset, duration = clip["trim_offset"] or 0.0, clip["trim_duration"]
        p = self.s.processing
        t0 = time.time()

        tr = await transcribe(src, offset, duration, p.whisper_model, p.whisper_threads,
                              groq_key=p.groq_api_key, session=self.session,
                              keep_loaded=p.whisper_keep_loaded)
        copy = await write_copy(self.session, p.anthropic_api_key, p.anthropic_model, clip,
                                tr.text, tr.language, p.cta_text, p.ad_disclosure)

        if copy.score is not None and copy.score < p.min_ai_score:
            log.info("Clip %s jeté par l'IA (note %s/10)", cid, copy.score)
            self.store.update_clip(cid, status="discarded", ai_score=copy.score,
                                   transcript=tr.text, hook=copy.hook)
            src.unlink(missing_ok=True)
            self.store.update_clip(cid, raw_path=None)
            return

        layout = await analyze(src, offset, duration)
        out = self.final_dir / f"clip_{cid}.mp4"
        ass = build_ass(tr.words, copy.hook, layout.kind, duration, p.font)
        if not await render(src, offset, duration, layout, ass, out,
                            height=p.output_height, preset=p.x264_preset):
            raise RuntimeError("montage FFmpeg échoué")

        src.unlink(missing_ok=True)  # le brut ne sert plus
        self.store.update_clip(cid, status="ready", raw_path=None, final_path=str(out),
                               transcript=tr.text, hook=copy.hook, caption=copy.caption,
                               ai_score=copy.score)
        log.info("Clip %s prêt en %.0fs (%s, note %s)", cid, time.time() - t0,
                 layout.kind, copy.score)

        if self.auto and self.store.claim(cid, "ready", "approved"):
            self._publish_wake.set()
            return
        header = (f"{EMOJI.get(clip['reason'], '⚡')} #{cid} · {clip['channel']} "
                  f"({clip['platform']}) · {duration:.0f}s"
                  + (f" · IA {copy.score}/10" if copy.score is not None else ""))
        mid = await self.tg.send_clip(cid, out, copy.caption, header)
        if mid:
            self.store.update_clip(cid, tg_message_id=mid)

    # ------------------------------------------------------------ publication
    async def run_publisher(self) -> None:
        while True:
            row = self.store.next_clip("approved")
            if row is None:
                self._publish_wake.clear()
                try:
                    await asyncio.wait_for(self._publish_wake.wait(), 60)
                except asyncio.TimeoutError:
                    pass
                continue
            cid = row["id"]
            if not (self.tiktok.configured and self.tiktok.connected):
                # Pas de TikTok : la vidéo est dans Telegram, tu la postes à la main.
                self.store.update_clip(cid, status="published", publish_id="manual")
                if self.auto:
                    await self.tg.send_clip(cid, Path(row["final_path"]), row["caption"] or "",
                                            f"#{cid} prêt (auto) — TikTok non connecté")
                continue
            if not self.store.claim(cid, "approved", "publishing"):
                continue
            try:
                pid = await self.tiktok.publish(Path(row["final_path"]), row["caption"] or "",
                                                branded=self.s.processing.ad_disclosure)
                self.store.update_clip(cid, status="published", publish_id=pid)
                where = ("en brouillon dans ton app TikTok — touche Publier"
                         if self.tiktok.mode == "inbox" else "publié sur TikTok")
                await self.tg.send(f"✅ Clip #{cid} {where}.")
            except TikTokError as e:
                self.store.update_clip(cid, status="failed", error=str(e)[:500])
                await self.tg.send(f"⚠️ Clip #{cid} : publication TikTok échouée\n{e}")
            # Limite TikTok : 6 requêtes/min par jeton -> on espace les envois
            await asyncio.sleep(30)

    # ---------------------------------------------------------------- ménage
    async def run_janitor(self) -> None:
        while True:
            limit = time.time() - self.s.processing.retention_days * 86400
            for row in self.store.expired(limit):
                for key in ("raw_path", "final_path"):
                    if row[key]:
                        Path(row[key]).unlink(missing_ok=True)
                self.store.update_clip(row["id"], raw_path=None, final_path=None)
            await asyncio.sleep(3600)
