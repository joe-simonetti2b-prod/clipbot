"""
Traduction des sous-titres (ex. streamer US -> sous-titres français).

C'est un levier fort pour un compte français : le public FR ne suit pas un
live anglais, mais regarde volontiers un moment fort sous-titré — et un clip
traduit est nettement plus « transformé » qu'une simple rediffusion.

Méthode : on regroupe les mots en phrases, on traduit toutes les phrases en un
seul appel IA, puis on répartit les mots traduits sur la durée de chaque phrase
(au prorata de leur longueur). Le rendu karaoké fonctionne ensuite à l'identique.
"""
from __future__ import annotations

import json
import logging

import aiohttp

from .llm import LLM, ask_json
from .transcribe import Word

log = logging.getLogger(__name__)

NAMES = {"fr": "français", "en": "anglais", "es": "espagnol", "de": "allemand",
         "it": "italien", "pt": "portugais"}


def sentences(words: list[Word], max_gap: float = 0.8, max_words: int = 14) -> list[list[Word]]:
    out: list[list[Word]] = []
    cur: list[Word] = []
    for w in words:
        if cur and (w.start - cur[-1].end > max_gap or len(cur) >= max_words
                    or cur[-1].text.endswith((".", "!", "?"))):
            out.append(cur)
            cur = []
        cur.append(w)
    if cur:
        out.append(cur)
    return out


def spread(text: str, start: float, end: float, limit: float | None = None) -> list[Word]:
    """Répartit les mots d'une phrase traduite sur [start, end] selon leur longueur.
    Une traduction plus longue peut déborder un peu (0,3 s/mot minimum pour rester
    lisible), sans jamais empiéter sur la phrase suivante (limit)."""
    toks = text.split()
    if not toks:
        return []
    total = sum(len(t) + 1 for t in toks)
    span = max(end - start, 0.3 * len(toks))
    if limit is not None:
        span = max(min(span, limit - start), end - start)
    words, t = [], start
    for tok in toks:
        d = span * (len(tok) + 1) / total
        words.append(Word(round(t, 3), round(t + d, 3), tok))
        t += d
    return words


async def translate_words(session: aiohttp.ClientSession, llm: LLM, words: list[Word],
                          source: str, target: str) -> list[Word] | None:
    """Renvoie les mots traduits horodatés, ou None (on garde alors la version originale)."""
    if not (llm.enabled and words and target and source and source != target):
        return None
    sents = sentences(words)
    lines = [" ".join(w.text for w in s) for s in sents]
    prompt = (
        f"Traduis ces répliques d'un live ({NAMES.get(source, source)}) en {NAMES.get(target, target)} "
        "naturel et parlé, comme des sous-titres de clip viral : court, punchy, garde l'argot "
        "et les jurons au même niveau, ne traduis pas les pseudos ni les noms propres.\n"
        f"Entrée (tableau JSON de {len(lines)} lignes) :\n{json.dumps(lines, ensure_ascii=False)}\n\n"
        f'Réponds {{"lines": [...]}} avec exactement {len(lines)} chaînes, dans le même ordre.'
    )
    obj = await ask_json(session, llm, prompt, max_tokens=1500)
    out = (obj or {}).get("lines")
    if not isinstance(out, list) or len(out) != len(sents):
        log.warning("Traduction inutilisable -> sous-titres d'origine")
        return None
    result: list[Word] = []
    for i, (s, text) in enumerate(zip(sents, out)):
        nxt = sents[i + 1][0].start if i + 1 < len(sents) else None
        result += spread(str(text).strip(), s[0].start, s[-1].end, nxt)
    return result
