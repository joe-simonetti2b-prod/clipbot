"""
Tests de bout en bout hors-ligne de la post-production et du service :
vidéo simulée -> clip 9:16 sous-titré, flux de validation, pages web,
démarrage/arrêt propre du service complet.
"""
import asyncio
import json
import os
import signal
import subprocess
from pathlib import Path
from types import SimpleNamespace

import aiohttp
import pytest
from aiohttp.test_utils import TestClient, TestServer

from clipbot import pipeline as pipeline_mod
from clipbot.config import Settings
from clipbot.discovery import parse_channel
from clipbot.layout import Layout
from clipbot.models import Platform
from clipbot.render import render
from clipbot.storage import Store
from clipbot.subtitles import build_ass, chunk_words
from clipbot.tiktok import TikTokClient
from clipbot.transcribe import Transcript, Word, parse_groq
from clipbot.web import build_app

WORDS = [Word(0.2, 0.5, "Non"), Word(0.5, 0.9, "mais"), Word(0.9, 1.3, "regarde"),
         Word(1.5, 1.9, "ça!"), Word(2.6, 3.0, "C'est"), Word(3.0, 3.6, "incroyable")]


def probe(path: Path) -> dict:
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration",
         "-of", "json", str(path)], capture_output=True, text=True, check=True).stdout
    return json.loads(out)


@pytest.fixture(scope="module")
def source_video(tmp_path_factory) -> Path:
    p = tmp_path_factory.mktemp("src") / "raw.ts"
    subprocess.run(
        ["ffmpeg", "-loglevel", "error", "-y",
         "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=30",
         "-f", "lavfi", "-i", "sine=frequency=330:sample_rate=48000",
         "-t", "16", "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", "-f", "mpegts", str(p)],
        check=True)
    return p


def test_parse_channel():
    assert parse_channel("Kamet0") == (Platform.TWITCH, "kamet0")
    assert parse_channel("kick:foo") == (Platform.KICK, "foo")
    assert parse_channel("https://www.twitch.tv/bar/") == (Platform.TWITCH, "bar")


def test_subtitles_chunking_and_hook():
    chunks = chunk_words(WORDS)
    assert [len(c) for c in chunks] == [3, 1, 2]  # coupe sur « ça! » et sur la pause
    ass = build_ass(WORDS, "Il ne s'attendait pas à ça", "blur", 8)
    assert "Style: Hook" in ass and "INCROYABLE" in ass and ass.count("Dialogue: 0") == 6


@pytest.mark.parametrize("layout", [
    Layout("blur"), Layout("face", cx=0.3), Layout("split", cam=(0.7, 0.65, 0.3, 0.3)),
])
def test_render_layouts(tmp_path, source_video, layout):
    out = tmp_path / f"{layout.kind}.mp4"
    ass = build_ass(WORDS, "Test du hook", layout.kind, 6)
    assert asyncio.run(render(source_video, 2.0, 6.0, layout, ass, out))
    info = probe(out)
    v = next(s for s in info["streams"] if s["codec_type"] == "video")
    assert (v["width"], v["height"]) == (1080, 1920)
    assert any(s["codec_type"] == "audio" for s in info["streams"])
    assert float(info["format"]["duration"]) == pytest.approx(6, abs=0.2)


class FakeTelegram:
    def __init__(self):
        self.clips, self.messages = [], []
        self.on_approve = self.on_reject = None

    async def send_clip(self, cid, path, caption, header):
        self.clips.append((cid, path, caption, header))
        return 42

    async def send(self, text, chat_id=None):
        self.messages.append(text)


def test_full_pipeline_to_validation(tmp_path, source_video, monkeypatch):
    async def fake_transcribe(*a, **k):
        return Transcript(WORDS, "fr")
    monkeypatch.setattr(pipeline_mod, "transcribe", fake_transcribe)

    s = Settings()
    s.capture.work_dir = tmp_path
    s.processing.anthropic_api_key = ""
    store = Store(tmp_path / "t.db")
    raw = tmp_path / "raw.ts"
    raw.write_bytes(source_video.read_bytes())
    cid = store.add_clip(platform="twitch", channel="demo", stream_title="Finale de folie",
                         category="Just Chatting", reason="rire", score=6.2,
                         raw_path=str(raw), trim_offset=3.0, trim_duration=8.0)

    async def scenario():
        async with aiohttp.ClientSession() as session:
            tg = FakeTelegram()
            tt = TikTokClient("", "", "inbox", "", store, session)
            p = pipeline_mod.Pipeline(s, store, session, tg, tt)
            await p._process(dict(store.clip(cid)))
            row = store.clip(cid)
            assert row["status"] == "ready" and Path(row["final_path"]).exists()
            assert not raw.exists()  # le brut est supprimé après montage
            assert tg.clips and "🎥 demo en live sur Twitch" in tg.clips[0][2]
            assert float(probe(Path(row["final_path"]))["format"]["duration"]) == pytest.approx(8, abs=0.2)
            # Validation depuis Telegram, puis un double appui est ignoré
            assert "Validé" in await p.approve(cid)
            assert await p.approve(cid) == "Déjà traité"
            assert store.clip(cid)["status"] == "approved"
    asyncio.run(scenario())


def test_render_light_profile(tmp_path, source_video):
    out = tmp_path / "light.mp4"
    ass = build_ass(WORDS, "Profil gratuit", "blur", 5)
    assert asyncio.run(render(source_video, 1.0, 5.0, Layout("blur"), ass, out,
                              height=1280, preset="ultrafast"))
    v = next(s for s in probe(out)["streams"] if s["codec_type"] == "video")
    assert (v["width"], v["height"]) == (720, 1280)


def test_groq_response_parsing():
    tr = parse_groq({"language": "French", "words": [
        {"word": " Salut", "start": 0.0, "end": 0.4}, {"word": "", "start": 0.4, "end": 0.5},
        {"word": "tout", "start": 0.5, "end": 0.8}]})
    assert tr.language == "fr" and tr.text == "Salut tout" and tr.words[1].start == 0.5


def test_tiktok_chunking():
    tt = TikTokClient("k", "s", "inbox", "https://x", None, None)
    src, chunk = tt._source(30 * 1024 * 1024)
    assert src["total_chunk_count"] == 1 and chunk == src["video_size"]
    src, chunk = tt._source(100 * 1024 * 1024)
    assert chunk == 10 * 1024 * 1024 and src["total_chunk_count"] == 10


def test_web_routes(tmp_path):
    s = Settings()
    s.publish.telegram_pair_code = "secret"
    fake = SimpleNamespace(s=s, orch=SimpleNamespace(paused=False, watchers={}),
                           tiktok=SimpleNamespace(configured=False), tg=FakeTelegram())

    async def scenario():
        async with TestClient(TestServer(build_app(fake))) as c:
            assert (await c.get("/health")).status == 200
            assert "confidentialité" in await (await c.get("/privacy")).text()
            assert (await c.get("/tiktok/login?k=faux")).status == 403
            assert (await c.get("/tiktok/login?k=secret")).status == 503  # pas de clés TikTok
    asyncio.run(scenario())


def test_service_starts_and_stops_cleanly(tmp_path, monkeypatch):
    from clipbot.app import App
    monkeypatch.setenv("PORT", "18765")
    monkeypatch.setenv("CLIPBOT_WORKDIR", str(tmp_path))
    for k in ("TELEGRAM_BOT_TOKEN", "TWITCH_CLIENT_ID", "ALLOWED_CHANNELS"):
        monkeypatch.delenv(k, raising=False)

    async def scenario():
        app = App(Settings())
        task = asyncio.create_task(app.run())
        await asyncio.sleep(1.5)
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:18765/health") as r:
                assert r.status == 200
        os.kill(os.getpid(), signal.SIGTERM)
        await asyncio.wait_for(task, 10)
    asyncio.run(scenario())


def test_pairing_cannot_be_hijacked(tmp_path):
    from clipbot.telegram import TelegramBot
    store = Store(tmp_path / "p.db")
    sent = []

    async def scenario():
        bot = TelegramBot("", "1234", store, None)
        async def fake_send(text, chat_id=None):
            sent.append((chat_id, text))
        bot.send = fake_send
        msg = lambda cid, t: {"message": {"chat": {"id": cid}, "text": t}}
        await bot._handle(msg(111, "/start 1234"))        # propriétaire légitime
        await bot._handle(msg(999, "/start 1234"))        # intrus avec le bon code
        assert bot.owner == 111
        env_bot = TelegramBot("", "1234", store, None, owner_id="222")
        assert env_bot.owner == 222                      # la variable d'environnement prime
    asyncio.run(scenario())
    assert any("Refusé" in t for _, t in sent)
