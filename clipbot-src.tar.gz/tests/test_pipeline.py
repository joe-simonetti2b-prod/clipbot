"""
Tests de bout en bout hors-ligne de la post-production et du service :
vidéo simulée -> clip 9:16 sous-titré, flux de validation, pages web,
démarrage/arrêt propre du service complet.
"""
import asyncio
import json
import os
import signal
import subprocess
from pathlib import Path
from types import SimpleNamespace

import aiohttp
import pytest
from aiohttp.test_utils import TestClient, TestServer

from clipbot import pipeline as pipeline_mod
from clipbot.config import Settings
from clipbot.discovery import parse_channel
from clipbot.layout import Layout
from clipbot.models import Platform
from clipbot.render import render
from clipbot.storage import Store
from clipbot.subtitles import build_ass, chunk_words
from clipbot.tiktok import TikTokClient
from clipbot.transcribe import Transcript, Word, parse_groq
from clipbot.web import build_app

WORDS = [Word(0.2, 0.5, "Non"), Word(0.5, 0.9, "mais"), Word(0.9, 1.3, "regarde"),
         Word(1.5, 1.9, "ça!"), Word(2.6, 3.0, "C'est"), Word(3.0, 3.6, "incroyable")]


def probe(path: Path) -> dict:
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "stream=codec_type,width,height:format=duration",
         "-of", "json", str(path)], capture_output=True, text=True, check=True).stdout
    return json.loads(out)


@pytest.fixture(scope="module")
def source_video(tmp_path_factory) -> Path:
    p = tmp_path_factory.mktemp("src") / "raw.ts"
    subprocess.run(
        ["ffmpeg", "-loglevel", "error", "-y",
         "-f", "lavfi", "-i", "testsrc2=size=1280x720:rate=30",
         "-f", "lavfi", "-i", "sine=frequency=330:sample_rate=48000",
         "-t", "16", "-c:v", "libx264", "-preset", "ultrafast", "-c:a", "aac", "-f", "mpegts", str(p)],
        check=True)
    return p


def test_parse_channel():
    assert parse_channel("Kamet0") == (Platform.TWITCH, "kamet0")
    assert parse_channel("kick:foo") == (Platform.KICK, "foo")
    assert parse_channel("https://www.twitch.tv/bar/") == (Platform.TWITCH, "bar")


def test_subtitles_chunking_and_hook():
    chunks = chunk_words(WORDS)
    assert [len(c) for c in chunks] == [3, 1, 2]  # coupe sur « ça! » et sur la pause
    ass = build_ass(WORDS, "Il ne s'attendait pas à ça", "blur", 8)
    assert "Style: Hook" in ass and "INCROYABLE" in ass and ass.count("Dialogue: 0") == 6


@pytest.mark.parametrize("layout", [
    Layout("blur"), Layout("face", cx=0.3), Layout("split", cam=(0.7, 0.65, 0.3, 0.3)),
])
def test_render_layouts(tmp_path, source_video, layout):
    out = tmp_path / f"{layout.kind}.mp4"
    ass = build_ass(WORDS, "Test du hook", layout.kind, 6)
    assert asyncio.run(render(source_video, 2.0, 6.0, layout, ass, out))
    info = probe(out)
    v = next(s for s in info["streams"] if s["codec_type"] == "video")
    assert (v["width"], v["height"]) == (1080, 1920)
    assert any(s["codec_type"] == "audio" for s in info["streams"])
    assert float(info["format"]["duration"]) == pytest.approx(6, abs=0.2)


class FakeTelegram:
    def __init__(self):
        self.clips, self.messages = [], []
        self.on_approve = self.on_reject = None

    async def send_clip(self, cid, path, caption, header):
        self.clips.append((cid, path, caption, header))
        return 42

    async def send(self, text, chat_id=None):
        self.messages.append(text)


def test_full_pipeline_to_validation(tmp_path, source_video, monkeypatch):
    async def fake_transcribe(*a, **k):
        return Transcript(WORDS, "fr")
    monkeypatch.setattr(pipeline_mod, "transcribe", fake_transcribe)

    s = Settings()
    s.capture.work_dir = tmp_path
    s.processing.anthropic_api_key = ""
    s.processing.channel_tags = {"demo": "@demo #democlips"}
    store = Store(tmp_path / "t.db")
    raw = tmp_path / "raw.ts"
    raw.write_bytes(source_video.read_bytes())
    cid = store.add_clip(platform="twitch", channel="demo", stream_title="Finale de folie",
                         category="Just Chatting", reason="rire", score=6.2,
                         raw_path=str(raw), trim_offset=3.0, trim_duration=8.0)

    async def scenario():
        async with aiohttp.ClientSession() as session:
            tg = FakeTelegram()
            tt = TikTokClient("", "", "inbox", "", store, session)
            p = pipeline_mod.Pipeline(s, store, session, tg, tt)
            await p._process(dict(store.clip(cid)))
            row = store.clip(cid)
            assert row["status"] == "ready" and Path(row["final_path"]).exists()
            assert not raw.exists()  # le brut est supprimé après montage
            assert tg.clips and "🎥 demo en live sur Twitch" in tg.clips[0][2]
            assert "@demo #democlips" in tg.clips[0][2]  # mentions de campagne
            assert float(probe(Path(row["final_path"]))["format"]["duration"]) == pytest.approx(8, abs=0.2)
            # Validation depuis Telegram, puis un double appui est ignoré
            assert "Validé" in await p.approve(cid)
            assert await p.approve(cid) == "Déjà traité"
            assert store.clip(cid)["status"] == "approved"
    asyncio.run(scenario())


def test_render_light_profile(tmp_path, source_video):
    out = tmp_path / "light.mp4"
    ass = build_ass(WORDS, "Profil gratuit", "blur", 5)
    assert asyncio.run(render(source_video, 1.0, 5.0, Layout("blur"), ass, out,
                              height=1280, preset="ultrafast"))
    v = next(s for s in probe(out)["streams"] if s["codec_type"] == "video")
    assert (v["width"], v["height"]) == (720, 1280)


def test_groq_response_parsing():
    tr = parse_groq({"language": "French", "words": [
        {"word": " Salut", "start": 0.0, "end": 0.4}, {"word": "", "start": 0.4, "end": 0.5},
        {"word": "tout", "start": 0.5, "end": 0.8}]})
    assert tr.language == "fr" and tr.text == "Salut tout" and tr.words[1].start == 0.5


def test_tiktok_chunking():
    tt = TikTokClient("k", "s", "inbox", "https://x", None, None)
    src, chunk = tt._source(30 * 1024 * 1024)
    assert src["total_chunk_count"] == 1 and chunk == src["video_size"]
    src, chunk = tt._source(100 * 1024 * 1024)
    assert chunk == 10 * 1024 * 1024 and src["total_chunk_count"] == 10


def test_web_routes(tmp_path):
    s = Settings()
    s.publish.telegram_pair_code = "secret"
    fake = SimpleNamespace(s=s, orch=SimpleNamespace(paused=False, watchers={}),
                           tiktok=SimpleNamespace(configured=False), tg=FakeTelegram())

    async def scenario():
        async with TestClient(TestServer(build_app(fake))) as c:
            assert (await c.get("/health")).status == 200
            assert "confidentialité" in await (await c.get("/privacy")).text()
            assert (await c.get("/tiktok/login?k=faux")).status == 403
            assert (await c.get("/tiktok/login?k=secret")).status == 503  # pas de clés TikTok
    asyncio.run(scenario())


def test_service_starts_and_stops_cleanly(tmp_path, monkeypatch):
    from clipbot.app import App
    monkeypatch.setenv("PORT", "18765")
    monkeypatch.setenv("CLIPBOT_WORKDIR", str(tmp_path))
    for k in ("TELEGRAM_BOT_TOKEN", "TWITCH_CLIENT_ID", "ALLOWED_CHANNELS"):
        monkeypatch.delenv(k, raising=False)

    async def scenario():
        app = App(Settings())
        task = asyncio.create_task(app.run())
        await asyncio.sleep(1.5)
        async with aiohttp.ClientSession() as s:
            async with s.get("http://127.0.0.1:18765/health") as r:
                assert r.status == 200
        os.kill(os.getpid(), signal.SIGTERM)
        await asyncio.wait_for(task, 10)
    asyncio.run(scenario())


def test_pairing_cannot_be_hijacked(tmp_path):
    from clipbot.telegram import TelegramBot
    store = Store(tmp_path / "p.db")
    sent = []

    async def scenario():
        bot = TelegramBot("", "1234", store, None)
        async def fake_send(text, chat_id=None):
            sent.append((chat_id, text))
        bot.send = fake_send
        msg = lambda cid, t: {"message": {"chat": {"id": cid}, "text": t}}
        await bot._handle(msg(111, "/start 1234"))        # propriétaire légitime
        await bot._handle(msg(999, "/start 1234"))        # intrus avec le bon code
        assert bot.owner == 111
        env_bot = TelegramBot("", "1234", store, None, owner_id="222")
        assert env_bot.owner == 222                      # la variable d'environnement prime
    asyncio.run(scenario())
    assert any("Refusé" in t for _, t in sent)


def test_channel_tags_parsing_and_credit(monkeypatch):
    monkeypatch.setenv("CHANNEL_TAGS", "xqc=@xqc #xqc; twitch:Kamet0=@kamet0 ;bad")
    s = Settings()
    assert s.processing.channel_tags == {"xqc": "@xqc #xqc", "kamet0": "@kamet0"}
    ass = build_ass(WORDS, "Hook", "blur", 5, credit="twitch.tv/xqc")
    assert "Credit,,0,0,0,,twitch.tv/xqc" in ass


# ---------------------------------------------------------------- v2 : rentabilité
def test_opencv_face_detector_available():
    import cv2
    c = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    assert not c.empty()


def test_translation_spreads_words_over_sentence():
    from clipbot import translate as tr_mod
    words = [Word(0.0, 0.3, "Bro"), Word(0.3, 0.6, "what"), Word(0.6, 1.0, "happened?"),
             Word(2.0, 2.4, "No"), Word(2.4, 3.0, "way")]
    assert [len(s) for s in tr_mod.sentences(words)] == [3, 2]

    async def fake_ask(session, llm, prompt, max_tokens=800):
        return {"lines": ["Frérot il s'est passé quoi ?", "Pas possible"]}

    async def scenario():
        orig = tr_mod.ask_json
        tr_mod.ask_json = fake_ask
        try:
            llm = tr_mod.LLM("groq", "k", "m")
            out = await tr_mod.translate_words(None, llm, words, "en", "fr")
        finally:
            tr_mod.ask_json = orig
        assert " ".join(w.text for w in out) == "Frérot il s'est passé quoi ? Pas possible"
        assert out[0].start == 0.0 and out[6].text == "Pas" and out[6].start == pytest.approx(2.0)
        assert out[5].end <= 2.0 + 1e-6  # la 1re phrase ne déborde pas sur la 2e
        assert all(a.end <= b.start + 1e-6 for a, b in zip(out, out[1:]))
        # même langue -> pas d'appel, pas de traduction
        assert await tr_mod.translate_words(None, llm, words, "fr", "fr") is None
    asyncio.run(scenario())


def test_backlog_keeps_only_best_clips(tmp_path):
    s = Settings()
    s.capture.work_dir = tmp_path
    s.processing.max_backlog = 2
    store = Store(tmp_path / "b.db")
    raws = []
    for score in (3.0, 9.0, 5.0, 12.0):
        f = tmp_path / f"r{score}.ts"
        f.write_bytes(b"x")
        raws.append(f)
        store.add_clip(platform="twitch", channel="x", reason="rire", score=score, raw_path=str(f))
    p = pipeline_mod.Pipeline(s, store, None, FakeTelegram(), TikTokClient("", "", "inbox", "", store, None))
    p.trim_backlog()
    kept = sorted(r["score"] for r in store.db.execute("SELECT score FROM clips WHERE status='extracted'"))
    assert kept == [9.0, 12.0]
    assert not raws[0].exists() and not raws[2].exists() and raws[3].exists()


def test_low_ai_score_is_never_rendered(tmp_path, source_video, monkeypatch):
    async def fake_transcribe(*a, **k):
        return Transcript(WORDS, "fr")

    async def fake_copy(*a, **k):
        from clipbot.copywriter import Copy
        return Copy("hook", "caption", 2)

    async def boom(*a, **k):
        raise AssertionError("le montage ne doit pas être lancé")
    monkeypatch.setattr(pipeline_mod, "transcribe", fake_transcribe)
    monkeypatch.setattr(pipeline_mod, "write_copy", fake_copy)
    monkeypatch.setattr(pipeline_mod, "render", boom)
    s = Settings()
    s.capture.work_dir = tmp_path
    store = Store(tmp_path / "d.db")
    raw = tmp_path / "raw.ts"
    raw.write_bytes(source_video.read_bytes())
    cid = store.add_clip(platform="twitch", channel="x", reason="burst", score=4,
                         raw_path=str(raw), trim_offset=0, trim_duration=5)

    async def scenario():
        p = pipeline_mod.Pipeline(s, store, None, FakeTelegram(), TikTokClient("", "", "inbox", "", store, None))
        await p._process(dict(store.clip(cid)))
    asyncio.run(scenario())
    assert store.clip(cid)["status"] == "discarded" and not raw.exists()


def test_youtube_metadata_and_resumable_upload(tmp_path, monkeypatch):
    import time as _t
    from aiohttp import web
    from clipbot import youtube as yt_mod

    meta = yt_mod.build_metadata("Quelle action\n\n#xqc #clip #fyp", "Il ne s'y attendait pas", "public")
    assert meta["snippet"]["title"].endswith("#Shorts") and meta["snippet"]["tags"] == ["xqc", "clip", "fyp"]

    got = {}

    async def init(req):
        got["meta"] = await req.json()
        got["len"] = req.headers["X-Upload-Content-Length"]
        return web.Response(headers={"Location": str(req.url.with_path("/put"))})

    async def put(req):
        got["body"] = await req.read()
        return web.json_response({"id": "abc123"})

    app = web.Application()
    app.add_routes([web.post("/upload", init), web.put("/put", put)])
    video = tmp_path / "v.mp4"
    video.write_bytes(b"0123456789")
    store = Store(tmp_path / "y.db")
    store.set("youtube_tokens", {"access_token": "t", "refresh_token": "r", "expires_at": _t.time() + 3600})

    async def scenario():
        async with TestServer(app) as srv, aiohttp.ClientSession() as session:
            monkeypatch.setattr(yt_mod, "UPLOAD_URL", str(srv.make_url("/upload")))
            c = yt_mod.YouTubeClient("id", "secret", "public", "https://x", store, session)
            assert c.configured and c.connected
            assert await c.publish(video, "légende #clip", "Hook") == "abc123"
    asyncio.run(scenario())
    assert got["body"] == b"0123456789" and got["len"] == "10"
    assert got["meta"]["status"]["privacyStatus"] == "public"
